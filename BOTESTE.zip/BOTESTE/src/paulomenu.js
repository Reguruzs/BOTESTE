const paulomenu = (prefix, pushname) => {
    return `◪ *Comandos do *ᏒᎬᎶᏬᏝᏬᏕ - B⃟O⃟T⃟*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.paulomenu = paulomenu
