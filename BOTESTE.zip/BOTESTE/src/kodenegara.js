const negara = (prefix, sender) => {
	return `*A*

Afganistan 93

Afrika Selatan 27

Afrika Tengah 236

Albania 355

Algeria (Aljazair) 213

Amerika Serikat 1

Andorra 376

Angola 244

Anguila 1-264

Antigua 1-268

Antillen Belanda 599

Arab Saudi 966

Argentina 54

Armenia 374

Aruba 297

Australia 61

Austria 43

Azerbaijan 994

*B*

Bahama 1-242

Bahrain 973

Bangladesh 880

Barbados 1-246

Barbuda 1-268

Belanda 31

Belarus 375

Belgia 32

Belize 501

Benin 229

Bermuda 1-441

Bhutan 975

Bolivia 591

Bosnia dan Herzegovina 387

Botswana 267

Brasil 55

Brunei Darussalam 673

Bulgaria 359

Burkina Faso 226

Burundi 257

*C*

Cape Verde 238

Ceko 420

Chad 235

Chili 56

Cina 86

Cina Makau 853

*D*

Denmark 45

Djibouti 253

Domikia 1-767

*E*

Ekuador 593

El Salvador 503

Eritrea 291

Estonia 372

Ethiopia 251

*F*

Fiji 679

Filipina 63

Finlandia 358

*G*

Gabon 241

Gambia 220

Georgia 995

Ghana 233

Gibraltar 350

Greenland 299

Grenada 1-473

Guam 1-671

Guatemala 502

Guinea 224

Guinea Bissau 245

Guinea Ekuator 240

Guyana 592

*H*

Haiti 509

Honduras 504

Hongaria 36

Hongkong 852

*I*

Indonesia 62

India 91

Inggris (Britania Raya) 44

Irak 964

Iran 98

Irlandia 353

Islandia 354

Israel 972

Italia 39

*J*

Jamaika 1-876

Jepang 81

Jerman 49

Jersey 44-1534

*K*

Kamboja 855

Kamerun 237

Kanada 1

Kazakhstan 7

Kenya 254

Kepulauan Marshall 692

Kepulauan Turks dan Caicos 1-649

Kirgizstan 996

Kiribati 686

Kolombia 57

Komoros 682

Korea Selatan 82

Korea Utara 850

Kosta Rika 506

Kroasia 385

Kuba 53

Kuwait 965

Kurakao 599

*L*

Laos 856

Latvia 371

Lebanon 961

Lesotho 266

Liberia 231

Libya 218

Liechtenstein 423

Lituania 370

Luksemburg 352

M

Madagaskar 261

Makedonia 389

Maladewa 960

Malawi 265

Malaysia 60

Mali 223

Malta 356

Maroko 212

Mauritania 222

Mauritius 230

Mayotte 262

Meksiko 52

Mesir 20

Mikronesia 691

Moldova 373

Monako 377

Mongolia 976

Montenegro 382

Mozambik 258

Myanmar 95

*N*

Namibia 264

Nauru 674

Nepal 977

Niger 227

Nigeria 234

Nikaragua 505

Niue 683

Norwegia 47

*O*

Oman 968

*P*

Pakistan 92

Palau 680

Palestina 970

Panama 507

Pantai Gading 225

Papua Nugini 675

Paraguay 595

Perancis 33

Perancis Polinesia 689

Peru 51

Pitcairn 64

Polandia 48

Portugal 351

Puerto Riko 1-787, 1-939

Pulau Cocos 61

Pulau Cook 682

Pulau Falkland 500

Pulau Faroe 298

Pulau Man 44-1624

Pulau Mariana Utara 1-670

Pulau Reuni 262

Pulau Solomon 677

Pulau Virgin 1-340

*Q*

Qatar 974

*R*

Republik Ceko 420

Republik Demokrasi Kongo 243

Republik Dominika 1-809, 1-829, 1-849

Rumania 40

Rusia 7

Rwanda 250

*S*

Sahara Barat 212

Santo Barthelemy 590

Santo Helena 290

Santo Kitts dan Nevis 1-869

Santo Lucia 1-758

Santo Vincent dan Grenadines 1-784

Samoa 685

San Marino 378

Sao Tome dan Principe 239

Selandia Baru 64

Senegal 221

Serbia 381

Seychelles 248

Sierra Leone 232

Singapura 65

Siprus 357

Slovenia 386

Slowakia 421

Somalia 252

Spanyol 34

Sri Lanka 94

Sudan 249

Sudan 211

Suriah 963

Suriname 597

Svalbard dan Jan Mayen 47

Swaziland 268

Swedia 46

Swiss 41

*T*

Tajikistan 992

Tanjung Verde 238

Tanzania 255

Taiwan 886

Thailand 66

Timor Leste 670

Togo 228

Tokelau 690

Tonga 676

Trinidad dan Tobago 1-868

Tunisia 216

Turki 90

Turkmenistan 993

Tuvalu 688

*U*

Uganda 256

Ukraina 380

Uni Emirat Arab 971

Uruguay 598

Uzbekistan 998

*V*

Vanuatu 678

Vatican 379

Venezuela 58

Vietnam 84

*W*

Walls dan Futuna 681

*Y*

Yaman 967

Yunani 30

Yordania 962

*Z*

Zambia 260

Zimbabwe 263`
}

exports.negara = negara
